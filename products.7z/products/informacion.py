from tkinter import ttk
from tkinter import *
import sqlite3

class infow:

    def __init__(self, ventanainfo):
        # Inicializando las ventanas
        self.ventanainfo = ventanainfo
        self.ventanainfo.title("McDonald's | Cliente")  # TITULO DE LA VENTANA
        self.ventanainfo.iconbitmap('Mcdonalds.ico')  # Para cambiar el icono de la esquina
        self.ventanainfo.resizable(False, False)  # Para que no se pueda expandir la pantalla


ventana_info = Tk()
ventana_info.geometry("600x600")
fondo4 = PhotoImage(file = "fondo4.png")
lblfondo4 = Label(ventana_info, image = fondo4).place(x=0, y=0)
info = infow(ventana_info)
ventana_info.mainloop()
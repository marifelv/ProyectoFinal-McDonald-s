from tkinter import ttk
from tkinter import *
import sqlite3
import subprocess
class menu:


    #El nombre del archivo de la base de datos
    db_name = "database.db"


    def __init__(self, ventana):

        # Inicializando las ventanas
        self.ventana = ventana
        self.ventana.title("McDonald's | Cliente")#TITULO DE LA VENTANA
        self.ventana.iconbitmap('Mcdonalds.ico')#Para cambiar el icono de la esquina
        self.ventana.resizable(False,False) #Para que no se pueda expandir la pantalla

        # Esta es la tabla con los productos
        self.tree = ttk.Treeview(height = 10, columns = 2)
        self.tree.grid(row = 4, column = 0, columnspan = 2)
        self.tree.place(relx = 0.0, rely = 1.0, anchor = "sw")
        self.tree.heading("#0", text = "Nombre", anchor = CENTER)
        self.tree.heading("#1", text = "Precio", anchor = CENTER)
        self.get_products()
        ventana.mainloop()


    #Función para ejecutar la consulta de la base de datos
    def run_query(self, query, parameters=()):

        with sqlite3.connect(self.db_name) as conn:

            cursor = conn.cursor()
            result = cursor.execute(query, parameters)
            conn.commit()

        return result


    def get_products(self):

        #Limpiando la tabla
        records = self.tree.get_children()
        for element in records:
            self.tree.delete(element)

        #Obteniendo los datos
        query = "SELECT * FROM product ORDER BY Nombre DESC"
        db_rows = self.run_query(query)

        #Rellenando datos
        for row in db_rows:
            self.tree.insert("", 0, text=row[1], values=row[2])



ventana_cliente = Tk()
ventana_cliente.geometry("400x450")
fondo3 = PhotoImage(file = "fondo3.png")
lblfondo3 = Label(ventana_cliente, image = fondo3).place(x=0, y=0)
cliente = menu(ventana_cliente)

ventana_cliente.mainloop()



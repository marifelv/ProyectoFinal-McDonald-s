#IMPORTAMOS LIBRERÍAS NECESARIAS.
from tkinter import ttk
from tkinter import *
import os

# Importa a los otros programas (modulo)
import subprocess


#CREAMOS VENTANA PRINCIPAL.
def ventana_inicio():

    global ventana_principal
    pestas_color="yellow2"
    pestas_color2="yellow2"
    ventana_principal=Tk()
    ventana_principal.geometry("650x350")#DIMENSIONES DE LA VENTANA
    fondo = PhotoImage(file = "fondo.png")
    lblfondo = Label(ventana_principal, image = fondo).place(x = 0, y = 0)
    ventana_principal.title("McDonald's | Registro y acceso de cuenta")#TITULO DE LA VENTANA
    ventana_principal.iconbitmap('Mcdonalds.ico')  # Para cambiar el icono de la esquina
    ventana_principal.resizable(False, False)  # Para que no se pueda expandir la pantalla
    Label(text="¡Bienvenido a McDonald's!\nPor favor, seleccione una opción", bg = "yellow", width = "300", height = "2", font = ("Calibri", 13)).pack()#ETIQUETA CON TEXTO
    Label(text="", bg='black').pack()
    Button(text="Acceder", height = "1", width = "10" , bg = 'red3', command = login).pack() #BOTÓN "Iniciar sesión"
    Label(text="",bg='black').pack()
    Button(text="Registrarse", height = "1", width = "10", bg = 'yellow2' , command = registro).pack() #BOTÓN "Registrarse".
    Label(text="",bg='black').pack()
    Button(text="Información", height="1", width="10", bg = 'green2', command = getinfo).pack()  # BOTÓN "Información".
    ventana_principal.mainloop()


#CREAMOS VENTANA PARA REGISTRO.
def registro():

    global ventana_registro
    ventana_registro = Toplevel(ventana_principal)
    ventana_registro.title("Registro de cuenta")
    ventana_registro.geometry("300x250")
    ventana_registro.iconbitmap('Mcdonalds.ico')  # Para cambiar el icono de la esquina
    global nombre_usuario
    global clave
    global entrada_nombre
    global entrada_clave
    nombre_usuario = StringVar() #DECLARAMOS "string" COMO TIPO DE DATO PARA "nombre_usuario"
    clave = StringVar() #DECLARAMOS "string" COMO TIPO DE DATO PARA "clave"
    Label(ventana_registro, text = "Por favor, introduzca sus datos", bg = "LightGreen").pack()
    Label(ventana_registro, text = "").pack()
    etiqueta_nombre = Label(ventana_registro, text = "Nombre de usuario:")
    etiqueta_nombre.pack()
    entrada_nombre = Entry(ventana_registro, textvariable = nombre_usuario) #ESPACIO PARA INTRODUCIR EL NOMBRE.
    entrada_nombre.pack()
    etiqueta_clave = Label(ventana_registro, text = "Contraseña:")
    etiqueta_clave.pack()
    entrada_clave = Entry(ventana_registro, textvariable = clave, show = "*") #ESPACIO PARA INTRODUCIR LA CONTRASEÑA.
    entrada_clave.pack()
    Label(ventana_registro, text = "").pack()
    Button(ventana_registro, text = "Registrarse", width = 8, height = 1, bg = "LightGreen", command = registro_usuario).pack() #BOTÓN "Registrarse"
    Label(ventana_registro, text="").pack()
    Button(ventana_registro, text = "Salir" , bg = "red2" , command=ventana_principal.destroy).pack()

#CREAMOS VENTANA PARA LOGIN.
def login():

    global ventana_login
    ventana_login = Toplevel(ventana_principal)
    ventana_login.title("   Ingresa a tu cuenta        ")
    ventana_login.geometry("410x300")
    ventana_login.iconbitmap('Mcdonalds.ico')  # Para cambiar el icono de la esquina
    Label(ventana_login, text = "Por favor, introduzca su nombre de usuario y contraseña correctamente.").pack()
    Label(ventana_login, text = "").pack()
    global verifica_usuario
    global verifica_clave
    verifica_usuario = StringVar()
    verifica_clave = StringVar()
    global entrada_login_usuario
    global entrada_login_clave
    Label(ventana_login, text = "Nombre usuario:").pack()
    entrada_login_usuario = Entry(ventana_login, textvariable=verifica_usuario)
    entrada_login_usuario.pack()
    Label(ventana_login, text = "").pack()
    Label(ventana_login, text = "Contraseña:").pack()
    entrada_login_clave = Entry(ventana_login, textvariable = verifica_clave, show = "*")
    entrada_login_clave.pack()
    Label(ventana_login, text = "").pack()
    Button(ventana_login, text = "Iniciar sesión",bg="green3", width=14, height=1, command = verifica_login).pack()



#VENTANA "VERIFICACION DE LOGIN".
def verifica_login():

    usuario1 = verifica_usuario.get()
    clave1 = verifica_clave.get()
    entrada_login_usuario.delete(0, END) #BORRA INFORMACIÓN DEL CAMPO "Nombre usuario *" AL MOSTRAR NUEVA VENTANA.
    entrada_login_clave.delete(0, END) #BORRA INFORMACIÓN DEL CAMPO "Contraseña *" AL MOSTRAR NUEVA VENTANA.
    lista_archivos = os.listdir() #GENERA LISTA DE ARCHIVOS UBICADOS EN EL DIRECTORIO.
    #SI EL NOMBRE SE ENCUENTRA EN LA LISTA DE ARCHIVOS..

    #Menú de administrador--> (Cuando el Usuario Administrador introduzca usuario = admin y clave = admind 
    #lo llevara a la ventana para de Menu)
    if usuario1 and clave1 == "admin":
        exito_loginadmin()

    else:

        if usuario1 in lista_archivos:
            archivo1 = open(usuario1, "r") #APERTURA DE ARCHIVO EN MODO LECTURA
            verifica = archivo1.read().splitlines() #LECTURA DEL ARCHIVO QUE CONTIENE EL nombre Y contraseña.
            #SI LA CONTRASEÑA INTRODUCIDA SE ENCUENTRA EN EL ARCHIVO...
            if clave1 in verifica:
                exito_login() #...EJECUTAR FUNCIÓN "exito_login()"
            #SI LA CONTRASEÑA NO SE ENCUENTRA EN EL ARCHIVO....
            else:
                no_clave() #...EJECUTAR "no_clave()"
        #SI EL NOMBRE INTRODUCIDO NO SE ENCUENTRA EN EL DIRECTORIO...
        else:
            no_usuario() #..EJECUTA "no_usuario()".


# VENTANA De inicio de sesión de cliente finalizado con éxito.
def exito_login():

    ventana_login.destroy()
    # Así fue que llamé al otro programa (index)
    subprocess.Popen(["python", "menuCliente.py"])


# VENTANA De inicio de sesión de administrador finalizado con éxito.
def exito_loginadmin():

    ventana_login.destroy()
    # Así fue que llamé al otro programa (index)
    subprocess.Popen(["python", "editarMenu.py"])

def getinfo():

    subprocess.Popen(["python", "informacion.py"])

 
#VENTANA DE "Contraseña incorrecta"
def no_clave():

    global ventana_no_clave
    ventana_no_clave = Toplevel(ventana_login)
    ventana_no_clave.iconbitmap('Mcdonalds.ico')  # Para cambiar el icono de la esquina
    ventana_no_clave.title("ERROR")
    ventana_no_clave.geometry("250x130")
    Label(ventana_no_clave, text = "Contraseña incorrecta\n Presione Ok para intentar Nuevamente").pack()
    Button(ventana_no_clave, text = "OK", command = borrar_no_clave).pack() #EJECUTA "borrar_no_clave()"
    Label(ventana_no_clave, text = "").pack()
    Button(ventana_no_clave, text= "Salir" , command=ventana_principal.destroy).pack()


#VENTANA DE "Usuario no encontrado".
def no_usuario():

    global ventana_no_usuario
    ventana_no_usuario = Toplevel(ventana_login)
    ventana_no_usuario.iconbitmap('Mcdonalds.ico')  # Para cambiar el icono de la esquina
    ventana_no_usuario.title("ERROR")
    ventana_no_usuario.geometry("250x130")
    Label(ventana_no_usuario, text = "Usuario no encontrado\nPresione Ok para intentar nuevamente\n").pack()
    Button(ventana_no_usuario, text = "OK", command = borrar_no_usuario).pack() #EJECUTA "borrar_no_usuario()"
    Label(ventana_no_usuario, text = "").pack()
    Button(ventana_no_usuario, text= "Salir" , command=ventana_principal.destroy).pack()



#CERRADO DE VENTANAS
def borrar_no_clave():
    ventana_no_clave.destroy() #--> .destroy es una funcion que elimina la ventana
 
 
def borrar_no_usuario():
    ventana_no_usuario.destroy()


#REGISTRO USUARIO
def registro_usuario():
 
    usuario_info = nombre_usuario.get()
    clave_info = clave.get()
    file = open(usuario_info, "w") #CREACION DE ARCHIVO CON "nombre" y "clave"
    file.write(usuario_info + "\n")
    file.write(clave_info)
    file.close()
    entrada_nombre.delete(0, END)
    entrada_clave.delete(0, END)
    Label(ventana_registro, text = "Registro completado con éxito", fg = "green", font = ("calibri", 11)).pack()
 
 
ventana_inicio()  #EJECUCIÓN DE LA VENTANA DE INICIO
